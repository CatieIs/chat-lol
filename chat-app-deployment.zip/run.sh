#!/bin/bash
cd server
python3 app.py
